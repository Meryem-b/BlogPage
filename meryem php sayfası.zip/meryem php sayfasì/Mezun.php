
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<meta name="author" content="Meryem sema bolat">

  <title>Meryem Sema Bolat</title>

  <link href="app.css" rel="stylesheet">
  <style>
	.test {
 	text-transform: uppercase;
	}
</style>
</head>

<body>

<header>
    <nav class="navbar navbar-expand-md navbar-light bg-white absolute-top">
      <div class="container">

        <button class="navbar-toggler order-2 order-md-1" type="button" data-toggle="collapse" data-target=".navbar-collapse" aria-controls="navbar-left navbar-right" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
<!-- BU coklu home idi ben kladırıp alttakini yaptım
        <div class="collapse navbar-collapse order-3 order-md-2" id="navbar-left">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item dropdown active">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" 
              aria-expanded="false">Home</a>
              <div class="dropdown-menu" aria-labelledby="dropdown01">
                <a class="dropdown-item" href="home-onecolumn.html">One column</a>
                <a class="dropdown-item" href="home-twocolumn.html">Two column</a>
                <a class="dropdown-item" href="home-threecolumn.html">Three column</a>
                <a class="dropdown-item" href="home-fourcolumn.html">Four column</a>
                <a class="dropdown-item" href="home-featured.html">Featured posts</a>
                <a class="dropdown-item" href="home-fullwidth.html">Full width</a>
              </div> 
            </li>-->

            <div class="collapse navbar-collapse order-3 order-md-2" id="navbar-left">
            <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="MeryemLoginPage.php">Home</a>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown03" data-toggle="dropdown" aria-haspopup="true"
               aria-expanded="false">Document</a>
              <div class="dropdown-menu" aria-labelledby="dropdown03">
              <a class="dropdown-item" href="MeryemArticles.php">Articles</a>
              <a class="dropdown-item" href="https://github.com/Meryem-b" target="_blank">GitHub Projects</a>
                <a class="dropdown-item" href="Java.php">Java</a>
                <a class="dropdown-item" href="Web.php">Web Programming</a>
              </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown02" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Posts</a>
              <div class="dropdown-menu" aria-labelledby="dropdown02">
              <a class="dropdown-item" href="MeryemSemaBolat.php">Life</a>
               <!-- <a class="dropdown-item" href="Mezun.php">Video</a> -->
                <a class="dropdown-item" href="MezunPig.php">Math. Eng.</a>
              </div>
            </li>

          
          </ul>
        </div>

        <a class="navbar-brand mx-auto order-1 order-md-3 test"   href="MeryemLoginPage.php">MSB</a>

        <div class="collapse navbar-collapse order-4 order-md-4" id="navbar-right">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="MeryemAboutPage.php">About</a>
            </li>
             <!--   <li class="nav-item">
              <a class="nav-link" href="page-contact.html">Contact</a>
            </li>
                    -->
          </ul>
          <form class="form-inline" role="search">
            <input class="search js-search form-control form-control-rounded mr-sm-2" type="text" title="Enter search query here.." placeholder="Search.." aria-label="Search">
          </form>
        </div>
      </div>
    </nav>
  </header>

  <main class="main pt-4">

    <div class="container">

      <div class="row">
        <div class="col-md-9">

          <article class="card mb-4">
            <header class="card-header text-center">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2019-10-21 20:00">9 September 2021</time></a> in <a href="page-category.html">University</a>
              </div>
              <a href="post-image.html">
                <h1 class="card-title">GRADUATION</h1>
              </a>
            </header>
            <a href="post-image.html" >
              <div class="vimeo" >
              <iframe width="560" height="315" src="https://www.youtube.com/embed/nn-WmXuFj-o" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                  </div>
                 
            </a>
   
            <div class="card-body">
            <p>

I received training in both applied mathematics and computer science. My graduation thesis is lie symmetries 
of differential equations. I chose this topic both to deal with equations and to show that how equations become
 easly with using the computer programming. So that, I used volfram mathematica. I did image processing with opencv
  in my internship and completed the given projects. I can use Python, C, C++, SQL, MATLAB, ( HTML — PHP — CSS — JS — mySQL) 
  and Latex effectively. Also, My hobbies are ice skating and creating a website. I am doing webpage  in my free time, and 
  during that time I’ve created the coffe shop <a href="https://web.itu.edu.tr/bolat16/Coffeehouse.php" target="_blank"><strong>
    CLICK HERE</strong></a> , designed and developed 
  a user-friendly website. Purchasing parts will be created and completed (in process). Also, ı created  web page
  <a href="https://www.beplusglobal.com/BePlus.php " target="_blank"><strong> 
    CLICK HERE</strong></a>
   for customer. And ı create  my blogpage
  <a href="https://web.itu.edu.tr/bolat16/Meryem/MeryemLoginPage.php " target="_blank"><strong>
    CLICK HERE</strong></a>.
  Inside the blog there are many project,
    documents and all my project is writen with latex. I believe I will continue to create different websites
     in my spare time. In Siemens, I took courses on java, python script, linux and computer basics. During my education,
      I tried to learn properly. My aim is to be open to new developments in the field of software and to provide rapid adaptation.
       I would like to state that I am extremely devoted and enthusiastic about being effective in business life.
       </p>
       <p> I am excited about the opportunity to join. Thank you
for taking the time to read my cover letter. </p>
<p> Sincerely </p>
                 
</p>
              <div class="row">
                <div class="col-md-4">
                  <ul>
                    <li>Donec quam felis</li>
                    <li>Consectetuer adipiscing</li>
                  </ul>
                </div>
                <div class="col-md-4">
                  <ul>
                    <li>Donec quam felis</li>
                    <li>Consectetuer adipiscing</li>
                  </ul>
                </div>
                <div class="col-md-4">
                  <ul>
                    <li>Donec quam felis</li>
                    <li>Consectetuer adipiscing</li>
                  </ul>
                </div>
              </div>

              <p>Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut m
                etus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. <strong>Etiam rhoncus</strong>. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante <a href="#">tincidunt tempus</a>.</p>

              <hr />

              <h3>4 comments</h3>

             

              <div class="mt-5">
                <h5>Write a response</h5>
                <div class="row">
                  <div class="col-md-6">
                    <input type="text" class="form-control" id="name" name="name" placeholder="Your name">
                  </div>
                  <div class="col-md-6">
                    <input type="email" class="form-control" id="email" name="email" placeholder="Your email">
                  </div>
                </div>
                <textarea class="form-control mt-3" rows="3" placeholder="Write a response.."></textarea>
                <a href="#" class="btn btn-success mt-3">Publish</a>
              </div>

            </div>
          </article><!-- /.card -->

        </div>
        <div class="col-md-3 ml-auto">

          <aside class="sidebar">
            <div class="card mb-4">
              <div class="card-body">
                <h4 class="card-title">About</h4>
                <p class="card-text">Graduation video of September 9, 2021.</p>
              </div>
            </div><!-- /.card -->
          </aside>

          <aside class="sidebar sidebar-sticky">
            <div class="card mb-4">
              <div class="card-body">
                <h4 class="card-title">Tags</h4>
                <a class="btn btn-light btn-sm mb-1" href="page-category.html">Journey</a>
                <a class="btn btn-light btn-sm mb-1" href="page-category.html">Work</a>
                <a class="btn btn-light btn-sm mb-1" href="page-category.html">Lifestype</a>
                <a class="btn btn-light btn-sm mb-1" href="page-category.html">Photography</a>
                <a class="btn btn-light btn-sm mb-1" href="page-category.html">University</a>
              </div>
            </div><!-- /.card -->
           
          </aside>

        </div>
      </div>
    </div>

    <br>

  </main>

 
  <div class="site-instagram">
    <div class="action">
      <a class="btn btn-light" href="https://www.instagram.com/meryemsemabolat/" target="_blank">
        Follow us @ Instagram
      </a>
    </div>
    <div class="row no-gutters">
      <div class="col-sm-6">
        <div class="row no-gutters">
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="111.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="8.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="13.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="4.jpg" alt="" />
            </a>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="row no-gutters">
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="99.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="6.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="10.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="222.jpg" alt="" />
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  
  <footer class="site-footer bg-darkest">
    <div class="container">

    <div class="row">
            <div class="col-md">
            <ul class="list-inline text-center text-md-start mb-3 my-md-4">
                   <li class="list-inline-item ms-5">
                    <a class="card-floating-icon" href="mailto:msemaa1@hotmail.com"  target="_blank">
                    <i class="fa fa-envelope" aria-hidden="true"></i>
        
                    <li class="list-inline-item">
                    <a class="text-white-75 text-primary-hover" href="https://www.linkedin.com/in/meryem-sema-bolat/" target="_blank">
                    <i class="fab fa-linkedin-in" aria-hidden="true"></i> 
                    
                    <li class="list-inline-item ms-5">
                    <a class="text-white-75 text-primary-hover"  href="https://www.facebook.com/meryembolaat/" target="_blank">
                    <i class="fab fa-facebook" aria-hidden="true"></i>

                 

                    <li class="list-inline-item ms-5">
                    <a class="text-white-75 text-primary-hover" href="https://www.instagram.com/meryemsemabolat/?hl=tr"  target="_blank">
                    <i class="fab fa-instagram" aria-hidden="true"></i> 
            </ul>
         
                
             <div class="copy"> &copy; MSB 2021  All rights reserved </div>
             </div>
             </div>
             </div>
             
    </footer>

  <script src="app.js"></script>
</body>
</html>
