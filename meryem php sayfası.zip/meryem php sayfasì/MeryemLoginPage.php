
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<meta name="author" content="Meryem sema bolat">

  <title>Meryem Sema Bolat</title>

  <link href="app.css" rel="stylesheet">
  <style>
	.test {
 	text-transform: uppercase;
	}
</style>
</head>
<body>

  <header>
    <nav class="navbar navbar-expand-md navbar-light bg-white absolute-top">
      <div class="container">

        <button class="navbar-toggler order-2 order-md-1" type="button" data-toggle="collapse" data-target=".navbar-collapse" aria-controls="navbar-left navbar-right" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
<!-- BU coklu home idi ben kladırıp alttakini yaptım
        <div class="collapse navbar-collapse order-3 order-md-2" id="navbar-left">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item dropdown active">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" 
              aria-expanded="false">Home</a>
              <div class="dropdown-menu" aria-labelledby="dropdown01">
                <a class="dropdown-item" href="home-onecolumn.html">One column</a>
                <a class="dropdown-item" href="home-twocolumn.html">Two column</a>
                <a class="dropdown-item" href="home-threecolumn.html">Three column</a>
                <a class="dropdown-item" href="home-fourcolumn.html">Four column</a>
                <a class="dropdown-item" href="home-featured.html">Featured posts</a>
                <a class="dropdown-item" href="home-fullwidth.html">Full width</a>
              </div> 
            </li>-->

            <div class="collapse navbar-collapse order-3 order-md-2" id="navbar-left">
            <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="MeryemLoginPage.php">Home</a>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown03" data-toggle="dropdown" aria-haspopup="true"
               aria-expanded="false">Document</a>
              <div class="dropdown-menu" aria-labelledby="dropdown03">
              <a class="dropdown-item" href="MeryemArticles.php">Articles</a>
              <a class="dropdown-item" href="https://github.com/Meryem-b" target="_blank">GitHub Projects</a>
                <a class="dropdown-item" href="Java.php">Java</a>
                <a class="dropdown-item" href="Web.php">Web Programming</a>
              </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown02" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Posts</a>
              <div class="dropdown-menu" aria-labelledby="dropdown02">
              <a class="dropdown-item" href="MeryemSemaBolat.php">Life</a>
               <!-- <a class="dropdown-item" href="Mezun.php">Video</a> -->
                <a class="dropdown-item" href="MezunPig.php">Math. Eng.</a>
              </div>
            </li>

           
          </ul>
        </div>

        <a class="navbar-brand mx-auto order-1 order-md-3 test"   href="MeryemLoginPage.php">MSB</a>

        <div class="collapse navbar-collapse order-4 order-md-4" id="navbar-right">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="MeryemAboutPage.php">About</a>
            </li>
    <!--   <li class="nav-item">
              <a class="nav-link" href="page-contact.html">Contact</a>
            </li>
                    -->
          </ul>
          <form class="form-inline" role="search">
            <input class="search js-search form-control form-control-rounded mr-sm-2" type="text" title="Enter search query here.." placeholder="Search.." aria-label="Search">
          </form>
        </div>
      </div>
    </nav>
  </header>

  <main class="main pt-4">

    <div class="intro">
      <div class="container-fluid">
        <div class="row">

          <div class="col-md-4">
            <a class="intro-block" href="https://drive.google.com/drive/folders/0B1Xqn1FNdYpRTlBxb2NpQTh4d1k?resourcekey=0-j3MirCqrEsAgksXJqkAfTg&usp=sharing" target ="_blank" style="background-image:url('doc.jpg')">
              <div class="intro-block-inner">
              <time class="timeago" datetime="2021-10-09 20:00">26 october 2021</time>
                              <h2>Documents and projects</h2>
              </div>
            </a>
          </div>
          <div class="col-md-4">
            <a class="intro-block active" href="https://drive.google.com/file/d/1MkIR5n2NmDdE-jrRwiatFiZsDvWCLuRG/view?usp=sharing " target ="_blank" style="background-image:url('work.jpg')">
              <div class="intro-block-inner">
              <time class="timeago" datetime="2021-10-09 20:00">26 october 2021</time>
                              <h2>CV</h2>
              </div>
            </a>
          </div>
          <div class="col-md-4">
            <a class="intro-block" href="MezunPig.php" style="background-image:url('ITU.jpg')">
              <div class="intro-block-inner">
                <time class="timeago" datetime="2021-10-09 20:00">26 october 2021</time>
                <h2>About Mathematical Engineering</h2>
              </div>
            </a>
          </div>

        </div>
      </div>
    </div>
<!--
    <div class="container">

      <hr />

      <div class="row">
        <div class="col-md-9">

          <div class="row">
            <div class="col-md-6">

              <article class="card mb-4">
                <header class="card-header">
                  <div class="card-meta">
                    <a href="#"><time class="timeago" datetime="2019-10-26 20:00">26 october 2019</time></a> in <a href="page-category.html">Journey</a>
                  </div>
                  <a href="post-image.html">
                    <h4 class="card-title">How can we sing about love?</h4>
                  </a>
                </header>
                <a href="post-image.html">
                  <img class="card-img" src="img/articles/22.jpg" alt="" />
                </a>
                <div class="card-body">
                  <p class="card-text">Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. </p>
                </div>
              </article>
              
              <article class="card mb-4">
                <header class="card-header">
                  <div class="card-meta">
                    <a href="#"><time class="timeago" datetime="2019-10-03 20:00">3 october 2019</time></a> in <a href="page-category.html">Lifestyle</a>
                  </div>
                  <a href="post-image.html">
                    <h4 class="card-title">Oh, I guess they have the blues</h4>
                  </a>
                </header>
                <a href="post-image.html">
                  <img class="card-img" src="img/articles/18.jpg" alt="" />
                </a>
                <div class="card-body">
                  <p class="card-text">Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. </p>
                </div>
              </article>

              <article class="card mb-4">
                <header class="card-header">
                  <div class="card-meta">
                    <a href="#"><time class="timeago" datetime="2019-07-16 20:00">16 july 2019</time></a> in <a href="page-category.html">Work</a>
                  </div>
                  <a href="post-image.html">
                    <h4 class="card-title">How can we, how can we sing about ourselves?</h4>
                  </a>
                </header>
                <a href="post-image.html">
                  <img class="card-img" src="img/articles/12.jpg" alt="" />
                </a>
                <div class="card-body">
                  <p class="card-text">Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. </p>
                </div>
              </article>

            </div>
            <div class="col-md-6">

              <article class="card mb-4">
                <header class="card-header">
                  <div class="card-meta">
                    <a href="#"><time class="timeago" datetime="2019-10-15 20:00">15 october 2019</time></a> in <a href="page-category.html">Lifestyle</a>
                  </div>
                  <a href="post-image.html">
                    <h4 class="card-title">The king is made of paper</h4>
                  </a>
                </header>
                <a href="post-image.html">
                  <img class="card-img" src="img/articles/21.jpg" alt="" />
                </a>
                <div class="card-body">
                  <p class="card-text">Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. </p>
                </div>
              </article>

              <article class="card mb-4">
                <header class="card-header">
                  <div class="card-meta">
                    <a href="#"><time class="timeago" datetime="2019-08-24 20:00">24 august 2019</time></a> in <a href="page-category.html">Work</a>
                  </div>
                  <a href="post-image.html">
                    <h4 class="card-title">Crying on the news</h4>
                  </a>
                </header>
                <a href="post-image.html">
                  <img class="card-img" src="img/articles/13.jpg" alt="" />
                </a>
                <div class="card-body">
                  <p class="card-text">Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. </p>
                </div>
              </article>

              <article class="card mb-4">
                <header class="card-header">
                  <div class="card-meta">
                    <a href="#"><time class="timeago" datetime="2019-05-08 20:00">8 may 2019</time></a> in <a href="page-category.html">Journey</a>
                  </div>
                  <a href="post-image.html">
                    <h4 class="card-title">How can you not sing about love?</h4>
                  </a>
                </header>
                <a href="post-image.html">
                  <img class="card-img" src="img/articles/1.jpg" alt="" />
                </a>
                <div class="card-body">
                  <p class="card-text">Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. </p>
                </div>
              </article>

            </div>
          </div>

        </div>
        <div class="col-md-3 ml-auto">

          <aside class="sidebar">
            <div class="card mb-4">
              <div class="card-body">
                <h4 class="card-title">About</h4>
                <p class="card-text">Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam <a href="#">semper libero</a>, sit amet adipiscing sem neque sed ipsum. </p>
              </div>
            </div>
          </aside>

          <aside class="sidebar sidebar-sticky">
            <div class="card mb-4">
              <div class="card-body">
                <h4 class="card-title">Tags</h4>
                <a class="btn btn-light btn-sm mb-1" href="page-category.html">Journey</a>
                <a class="btn btn-light btn-sm mb-1" href="page-category.html">Work</a>
                <a class="btn btn-light btn-sm mb-1" href="page-category.html">Lifestype</a>
                <a class="btn btn-light btn-sm mb-1" href="page-category.html">Photography</a>
                <a class="btn btn-light btn-sm mb-1" href="page-category.html">Food & Drinks</a>
              </div>
            </div>
            <div class="card mb-4">
              <div class="card-body">
                <h4 class="card-title">Popular stories</h4>

                <a href="post-image.html" class="d-inline-block">
                  <h4 class="h6">The blind man</h4>
                  <img class="card-img" src="img/articles/2.jpg" alt="" />
                </a>
                <time class="timeago" datetime="2019-10-03 20:00">3 october 2019</time> in Lifestyle

                <a href="post-image.html" class="d-inline-block mt-3">
                  <h4 class="h6">Crying on the news</h4>
                  <img class="card-img" src="img/articles/3.jpg" alt="" />
                </a>
                <time class="timeago" datetime="2019-07-16 20:00">16 july 2019</time> in Work

              </div>
            </div>
          </aside>

        </div>
      </div>
    </div>

    -->

  </main>

<br>


<div class="site-instagram">
    <div class="action">
      <a class="btn btn-light" href="https://www.instagram.com/meryemsemabolat/" target="_blank">
        Follow us @ Instagram
      </a>
    </div>
    <div class="row no-gutters">
      <div class="col-sm-6">
        <div class="row no-gutters">
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="111.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="8.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="13.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="4.jpg" alt="" />
            </a>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="row no-gutters">
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="99.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="6.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="10.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="222.jpg" alt="" />
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  
  <footer class="site-footer bg-darkest">
    <div class="container">

    <div class="row">
            <div class="col-md">
            <ul class="list-inline text-center text-md-start mb-3 my-md-4">
                   <li class="list-inline-item ms-5">
                    <a class="card-floating-icon" href="mailto:msemaa1@hotmail.com"  target="_blank">
                    <i class="fa fa-envelope" aria-hidden="true"></i>
        
                    <li class="list-inline-item">
                    <a class="text-white-75 text-primary-hover" href="https://www.linkedin.com/in/meryem-sema-bolat/" target="_blank">
                    <i class="fab fa-linkedin-in" aria-hidden="true"></i> 
                    
                    <li class="list-inline-item ms-5">
                    <a class="text-white-75 text-primary-hover"  href="https://www.facebook.com/meryembolaat/" target="_blank">
                    <i class="fab fa-facebook" aria-hidden="true"></i>

                 

                    <li class="list-inline-item ms-5">
                    <a class="text-white-75 text-primary-hover" href="https://www.instagram.com/meryemsemabolat/?hl=tr"  target="_blank">
                    <i class="fab fa-instagram" aria-hidden="true"></i> 
            </ul>
         
                
             <div class="copy"> &copy; MSB 2021  All rights reserved </div>
             </div>
             </div>
             </div>
             
    </footer>

  <script src="app.js"></script>
</body>
</html>
