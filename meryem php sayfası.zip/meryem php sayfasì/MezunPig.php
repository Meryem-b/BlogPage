
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<meta name="author" content="Meryem sema bolat">

  <title>Meryem Sema Bolat</title>

  <link href="app.css" rel="stylesheet">
  <style>
	.test {
 	text-transform: uppercase;
	}
</style>
</head>
<body>

  <header>
    <nav class="navbar navbar-expand-md navbar-light bg-white absolute-top">
      <div class="container">

        <button class="navbar-toggler order-2 order-md-1" type="button" data-toggle="collapse" data-target=".navbar-collapse" aria-controls="navbar-left navbar-right" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
<!-- BU coklu home idi ben kladırıp alttakini yaptım
        <div class="collapse navbar-collapse order-3 order-md-2" id="navbar-left">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item dropdown active">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" 
              aria-expanded="false">Home</a>
              <div class="dropdown-menu" aria-labelledby="dropdown01">
                <a class="dropdown-item" href="home-onecolumn.html">One column</a>
                <a class="dropdown-item" href="home-twocolumn.html">Two column</a>
                <a class="dropdown-item" href="home-threecolumn.html">Three column</a>
                <a class="dropdown-item" href="home-fourcolumn.html">Four column</a>
                <a class="dropdown-item" href="home-featured.html">Featured posts</a>
                <a class="dropdown-item" href="home-fullwidth.html">Full width</a>
              </div> 
            </li>-->

            <div class="collapse navbar-collapse order-3 order-md-2" id="navbar-left">
            <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="MeryemLoginPage.php">Home</a>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown03" data-toggle="dropdown" aria-haspopup="true"
               aria-expanded="false">Document</a>
              <div class="dropdown-menu" aria-labelledby="dropdown03">
              <a class="dropdown-item" href="MeryemArticles.php">Articles</a>
              <a class="dropdown-item" href="https://github.com/Meryem-b" target="_blank">GitHub Projects</a>
                <a class="dropdown-item" href="Java.php">Java</a>
                <a class="dropdown-item" href="Web.php">Web Programming</a>
              </div>
            </li>
            
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown02" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Posts</a>
              <div class="dropdown-menu" aria-labelledby="dropdown02">
              <a class="dropdown-item" href="MeryemSemaBolat.php">Life</a>
               <!-- <a class="dropdown-item" href="Mezun.php">Video</a> -->
                <a class="dropdown-item" href="MezunPig.php">Math. Eng.</a>
              </div>
            </li>

          </ul>
        </div>

        <a class="navbar-brand mx-auto order-1 order-md-3 test"   href="MeryemLoginPage.php">MSB</a>

        <div class="collapse navbar-collapse order-4 order-md-4" id="navbar-right">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="MeryemAboutPage.php">About</a>
            </li>
    <!--   <li class="nav-item">
              <a class="nav-link" href="page-contact.html">Contact</a>
            </li>
                    -->
          </ul>
          <form class="form-inline" role="search">
            <input class="search js-search form-control form-control-rounded mr-sm-2" type="text" title="Enter search query here.." placeholder="Search.." aria-label="Search">
          </form>
        </div>
      </div>
    </nav>
  </header>

  <main class="main pt-4">

    <div class="container">

      <div class="row">
        <div class="col-md-4">

          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2019-10-26 20:00">26 october 2019</time></a> in <a href="page-category.html">Journey</a>
              </div>
              <a href="post-image.html">
                <h4 class="card-title">What Does a Mathematical Engineer Mean?</h4>
              </a>
            </header>
            <a href="post-image.html">
              <img class="card-img" src="a.jpg" alt="" />
            </a>
            <div class="card-body">
              <p class="card-text">
                Mathematical engineer; It is the professional title given to the 
                person who analyzes the problems that occur or may occur 
                in sectors such as banking and industry, seeks and develops
                solutions to problems through mathematics. </p>
            </div>
          </article>

          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2019-10-03 20:00">3 october 2019</time></a> in <a href="page-category.html">Lifestyle</a>
              </div>
              <a href="post-image.html">
                <h4 class="card-title">What Does a Mathematical Engineer Do? What are their Duties and Responsibilities?</h4>
              </a>
            </header>
            <a href="post-image.html">
              <img class="card-img" src="teori.jpg" alt="" />
            </a>
            <div class="card-body">
              <p class="card-text">
                The main duties of the mathematical engineer, who is interested in the application area of mathematics, can be listed as follows:
                <br>
                To create mathematical modules of the problems that occur in the business field,
                <br>
                Performing mathematical analysis,
                <br>
                Solving and interpreting problems,
                <br>
                Making use of different computers and computer programs in problem solving,
                <br>
                Mainly by developing themselves in the fields of finance and software, combining the solutions in the workplace with these fields,
                <br>
                Developing different methods for solving problems,
                <br>
                Working in the field of industrial and computer science development,
                <br>
                Demonstrate work in areas such as computer labs when necessary. </p>
            </div>
          </article><!-- /.card -->
        </div>

        <div class="col-md-4">
          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2019-07-16 20:00">16 july 2019</time></a> in <a href="page-category.html">Work</a>
              </div>
              <a href="post-image.html">
                <h4 class="card-title">How to Become a Mathematical Engineer?</h4>
              </a>
            </header>
            <a href="post-image.html">
              <img class="card-img" src="mate.jpg" alt="" />
            </a>
            <div class="card-body">
              <p class="card-text">
                It is necessary to complete some educational processes to become a mathematical engineer
                who can perform long hours of analysis. After graduating from high school, one should 
                also graduate from the Department of Mathematics Engineering in the relevant faculties of universities. 
                After 4 years of undergraduate education, those who want to advance in the profession 
                can do a master's and doctorate.</p>
            </div>
          </article><!-- /.card -->

          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2019-10-15 20:00">15 october 2019</time></a> in <a href="page-category.html">Lifestyle</a>
              </div>
              <a href="post-image.html">
                <h4 class="card-title">Who can be successful in this department?</h4>
              </a>
            </header>
            <a href="post-image.html">
              <img class="card-img" src="dep.jpg" alt="" />
            </a>
            <div class="card-body">
              <p class="card-text">
                People who are interested in computer fields, who are interested in software or coding,
                who can easily use mathematics not only in theory but also in application areas, 
                who are prone to teamwork, who have high resistance to stress and difficulties,
                who are curious about the future and want to construct, can be successful. </p>
            </div>
          </article><!-- /.card -->
        </div>
        <div class="col-md-4">
          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2019-08-24 20:00">24 august 2019</time></a> in <a href="page-category.html">Work</a>
              </div>
              <a href="post-image.html">
                <h4 class="card-title">What are the challenges of Mathematical Engineering?</h4>
              </a>
            </header>
            <a href="post-image.html">
              <img class="card-img" src="computer.jpg" alt="" />
            </a>
            <div class="card-body">
              <p class="card-text">
                The popularity of the department is low because it is stuck between Computer and 
                Electronics Engineering because there is no specific job description, 
                and its education is given in only two schools. This is one of the main
                problems experienced by the department. </p>
            </div>
          </article><!-- /.card -->

          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2019-05-08 20:00">8 may 2019</time></a> in <a href="page-category.html">Journey</a>
              </div>
              <a href="post-image.html">
                <h4 class="card-title">How are the foreign opportunities of the department or sector?</h4>
              </a>
            </header>
            <a href="post-image.html">
              <img class="card-img" src="abr.jpg" alt="" />
            </a>
            <div class="card-body">
              <p class="card-text">
                The opportunities and employment rate of the engineering branch, which is known 
                as Computer Science/Applied Mathematic abroad, is increasing day by day. Therefore,
                job opportunities abroad are very rich. </p>
            </div>
          </article><!-- /.card -->

        </div>
      </div>
    </div>

    </main>
   
  <div class="site-instagram">
    <div class="action">
      <a class="btn btn-light" href="https://www.instagram.com/meryemsemabolat/" target="_blank">
        Follow us @ Instagram
      </a>
    </div>
    <div class="row no-gutters">
      <div class="col-sm-6">
        <div class="row no-gutters">
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="111.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="8.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="13.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="4.jpg" alt="" />
            </a>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="row no-gutters">
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="99.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="6.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="10.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="222.jpg" alt="" />
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  
  <footer class="site-footer bg-darkest">
    <div class="container">

    <div class="row">
            <div class="col-md">
            <ul class="list-inline text-center text-md-start mb-3 my-md-4">
                   <li class="list-inline-item ms-5">
                    <a class="card-floating-icon" href="mailto:msemaa1@hotmail.com"  target="_blank">
                    <i class="fa fa-envelope" aria-hidden="true"></i>
        
                    <li class="list-inline-item">
                    <a class="text-white-75 text-primary-hover" href="https://www.linkedin.com/in/meryem-sema-bolat/" target="_blank">
                    <i class="fab fa-linkedin-in" aria-hidden="true"></i> 
                    
                    <li class="list-inline-item ms-5">
                    <a class="text-white-75 text-primary-hover"  href="https://www.facebook.com/meryembolaat/" target="_blank">
                    <i class="fab fa-facebook" aria-hidden="true"></i>

                 

                    <li class="list-inline-item ms-5">
                    <a class="text-white-75 text-primary-hover" href="https://www.instagram.com/meryemsemabolat/?hl=tr"  target="_blank">
                    <i class="fab fa-instagram" aria-hidden="true"></i> 
            </ul>
         
                
             <div class="copy"> &copy; MSB 2021  All rights reserved </div>
             </div>
             </div>
             </div>
             
    </footer>

  <script src="app.js"></script>
</body>
</html>
