<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<meta name="author" content="Meryem sema bolat">

  <title>Meryem Sema Bolat</title>

  <link href="app.css" rel="stylesheet">

<style>
	.test {
 	text-transform: uppercase;
	}
</style>
</head>

<body>

<header>
    <nav class="navbar navbar-expand-md navbar-light bg-white absolute-top">
      <div class="container">

        <button class="navbar-toggler order-2 order-md-1" type="button" data-toggle="collapse" data-target=".navbar-collapse" aria-controls="navbar-left navbar-right" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
<!-- BU coklu home idi ben kladırıp alttakini yaptım
        <div class="collapse navbar-collapse order-3 order-md-2" id="navbar-left">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item dropdown active">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" 
              aria-expanded="false">Home</a>
              <div class="dropdown-menu" aria-labelledby="dropdown01">
                <a class="dropdown-item" href="home-onecolumn.html">One column</a>
                <a class="dropdown-item" href="home-twocolumn.html">Two column</a>
                <a class="dropdown-item" href="home-threecolumn.html">Three column</a>
                <a class="dropdown-item" href="home-fourcolumn.html">Four column</a>
                <a class="dropdown-item" href="home-featured.html">Featured posts</a>
                <a class="dropdown-item" href="home-fullwidth.html">Full width</a>
              </div> 
            </li>-->

            <div class="collapse navbar-collapse order-3 order-md-2" id="navbar-left">
            <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="MeryemLoginPage.php">Home</a>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown03" data-toggle="dropdown" aria-haspopup="true"
               aria-expanded="false">Document</a>
              <div class="dropdown-menu" aria-labelledby="dropdown03">
              <a class="dropdown-item" href="MeryemArticles.php">Articles</a>
              <a class="dropdown-item" href="https://github.com/Meryem-b" target="_blank">GitHub Projects</a>
                <a class="dropdown-item" href="Java.php">Java</a>
                <a class="dropdown-item" href="Web.php">Web Programming</a>
              </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown02" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Posts</a>
              <div class="dropdown-menu" aria-labelledby="dropdown02">
              <a class="dropdown-item" href="MeryemSemaBolat.php">Life</a>
               <!-- <a class="dropdown-item" href="Mezun.php">Video</a> -->
                <a class="dropdown-item" href="MezunPig.php">Math. Eng.</a>
              </div>
            </li>

		
          </ul>
        </div>

        <a class="navbar-brand mx-auto order-1 order-md-3 test"   href="MeryemLoginPage.php">MSB</a>
		
        <div class="collapse navbar-collapse order-4 order-md-4" id="navbar-right">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="MeryemAboutPage.php">About</a>
            </li>
              <!--   <li class="nav-item">
              <a class="nav-link" href="page-contact.html">Contact</a>
            </li>
                    -->
          </ul>
          <form class="form-inline" role="search">
            <input class="search js-search form-control form-control-rounded mr-sm-2" type="text" title="Enter search query here.." placeholder="Search.." aria-label="Search">
          </form>
        </div>
      </div>
    </nav>
  </header>

  <div class="row justify-content-center text-dark mb-100" >
      <div class="col-17 col-lg-18 col-xl-16">
            <br>
            <br>
                <p class="mb-4 show-on-scroll" data-show-duration="500" data-show-distance="10" data-show-delay="100" 
                style=" color:#daa520"  style =font-size:xx-large;><big><strong>TRAVEL, EXPLORE AND HAVE FUN ...</big></strong>
            <br>
  </div>
      </div>
 
  <main class="main pt-4">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2016-02-26 20:00">26 october 2016</time></a> in <a href="page-category.html">Journey</a>
              </div>
              
                <h4 class="card-title">Taal Lake</h4>
              
            </header>
            <a href="post-image.html">
              <img class="card-img" src="1.jpg" alt="" />
            </a>
            <div class="card-body">
              <p class="card-text">
              Taal Lake, located on the island of luzon, which I went to in 2016, completely changed my perspective on the world. and where I
               can see better, how can I travel more and how can I educate myself, I discovered who I am now. That's why this photo means so much to me.
              </p>
            </div>
          </article><!-- /.card -->


          
          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2021-08-03 20:00">3 november 2011</time></a> in <a href="page-category.html">Journey</a>
              </div>
              <a href="post-image.html">
                <h4 class="card-title">Ballica</h4>
              </a>
            </header>
            <div class="vimeo" >
                <iframe width="560" height="315" src="https://www.youtube.com/embed/zjUK5HqODRk" title="YouTube video player" frameborder="0" 
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen controls autoplay></iframe>
              </div>
            </a>
            <div class="card-body">
              <p class="card-text">Ballıca Cave, which was formed 3.5 million years ago and is located in the village of Ballıca of Pazar district, 26 kilometers from the city center of Tokat, and is referred to as the "8th wonder of the world" in the region, is shown as one of the largest and most magnificent caves in the world. It was exhilarating to be here.</p>
            </div>
          </article><!-- /.card -->
          </div>



        <div class="col-md-3">
          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2016-02-26 20:00">26 october 2016<</a> in <a href="page-category.html">Journey</a>
              </div>
               <h4 class="card-title">batangas philippines</h4>
              </a>
            </header>
            <a href="post-image.html">
              <img class="card-img" src="3.jpg" alt="" />
            </a>
            <div class="card-body">
              <p class="card-text">Batangas Island in the Philippines was the first remote island I went to with my backpack when I was 18. 
                My Philippine adventure, which I started with a single dictionary in my hand without even getting a phone call from Turkey and
                 knowing English, ended in the island of Batangas and I returned to my country for my education.
See you again... </p>
            </div>
          </article><!-- /.card -->



          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2021-08-03 20:00">3 november 2011</time></a> in <a href="page-category.html">Journey</a>
              </div>
              <a href="post-image.html">
                <h4 class="card-title">Dam </h4>
              </a>
              </header>
            <div class="vimeo" >
            <iframe width="560" height="315" src="https://www.youtube.com/embed/-slhzJ2nZ24" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
           </a>
            <div class="card-body">
              <p class="card-text">With the Çekerek Dam and HEPP, which ranks 10th among dams in Turkey in terms of water collection and capacity, 50 million kilowatt-hours of energy will be produced annually. We enjoyed the dam that accompanied us along the way. </p>
            </div>
         </article><!-- /.card -->
        </div>




        <div class="col-md-3">
          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2021-08-03 20:00">3 november 2011</time></a> in <a href="page-category.html">Journey</a>
              </div>
              <a href="post-image.html">
                <h4 class="card-title">Sato</h4>
              </a>
            </header>
            <div class="vimeo" >
                <iframe width="560" height="315" src="https://www.youtube.com/embed/9l1kD7E6Zmo" title="YouTube video player" frameborder="0" 
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen controls autoplay></iframe>
              </div>
               
          </a>
            <div class="card-body">
              <p class="card-text"> I've been to one of the beautiful hidden places in Turkey. The castle in Tokat fascinated me with its architecture that defies the years. He said goodbye to me with his hundreds of caves waiting to be explored. </p>
            </div>
       </article><!-- /.card -->


       
          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
              <a href="#"><time class="timeago" datetime="2021-08-03 20:00">3 november 2011</time></a> in <a href="page-category.html">Journey</a>
              </div>
              <a href="post-image.html">
                <h4 class="card-title">Sunflower</h4>
              </a>
              </header>
            <div class="vimeo" >
            <iframe width="560" height="315" src="https://www.youtube.com/embed/2aAcDcv6FN4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
           </a>
            <div class="card-body">
              <p class="card-text"> If you want to go to a place where there are endless sunflowers, this is your way. </p>
            </div>
          </article><!-- /.card -->
        </div>






        <div class="col-md-3">
          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
                <a href="#"><time class="timeago" datetime="2021-08-03 20:00">3 november 2011</time></a> in <a href="page-category.html">Journey</a>
              </div>
              <a href="post-image.html">
                <h4 class="card-title">Small town</h4>
              </a>
              </header>
            <div class="vimeo" >
            <iframe width="560" height="315" src="https://www.youtube.com/embed/qGPZM3EOipo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </a>
            <div class="card-body">
              <p class="card-text"> It has been a month that we have satisfied our longing for natural life by growing all kinds of natural fruits and vegetables in our farm. Even though it's nice to live in big cities, my admiration for towns will never end. </p>
            </div>
           </article><!-- /.card -->




          <article class="card mb-4">
            <header class="card-header">
              <div class="card-meta">
              <a href="#"><time class="timeago" datetime="2021-08-03 20:00">3 november 2011</time></a> in <a href="page-category.html">Journey</a>
              </div>
              <a href="post-image.html">
                <h4 class="card-title"> Natural</h4>
              </a>
              </header>
            <div class="vimeo" >
            <iframe width="560" height="315" src="https://www.youtube.com/embed/O-a192sNFxk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>              </div>
            </a>
            <div class="card-body">
              <p class="card-text"> The unique view of our village, as a result of this adventure that our ancestors started years ago by establishing a nature settlement, we became a village with 50 houses intertwined with nature. </p>
            </div>
           </article><!-- /.card -->
        </div>
      </div>
    </div>
  </main>

  
  <div class="site-instagram">
    <div class="action">
      <a class="btn btn-light" href="https://www.instagram.com/meryemsemabolat/" target="_blank">
        Follow us @ Instagram
      </a>
    </div>
    <div class="row no-gutters">
      <div class="col-sm-6">
        <div class="row no-gutters">
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="111.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="8.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="13.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="4.jpg" alt="" />
            </a>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="row no-gutters">
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="99.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="6.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="10.jpg" alt="" />
            </a>
          </div>
          <div class="col-3">
            <a class="photo" href="#">
              <img class="img-fluid" src="222.jpg" alt="" />
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  
  <footer class="site-footer bg-darkest">
    <div class="container">

    <div class="row">
            <div class="col-md">
            <ul class="list-inline text-center text-md-start mb-3 my-md-4">
                   <li class="list-inline-item ms-5">
                    <a class="card-floating-icon" href="mailto:msemaa1@hotmail.com"  target="_blank">
                    <i class="fa fa-envelope" aria-hidden="true"></i>
        
                    <li class="list-inline-item">
                    <a class="text-white-75 text-primary-hover" href="https://www.linkedin.com/in/meryem-sema-bolat/" target="_blank">
                    <i class="fab fa-linkedin-in" aria-hidden="true"></i> 
                    
                    <li class="list-inline-item ms-5">
                    <a class="text-white-75 text-primary-hover"  href="https://www.facebook.com/meryembolaat/" target="_blank">
                    <i class="fab fa-facebook" aria-hidden="true"></i>

                 

                    <li class="list-inline-item ms-5">
                    <a class="text-white-75 text-primary-hover" href="https://www.instagram.com/meryemsemabolat/?hl=tr"  target="_blank">
                    <i class="fab fa-instagram" aria-hidden="true"></i> 
            </ul>
         
                
             <div class="copy"> &copy; MSB 2021  All rights reserved </div>
             </div>
             </div>
             </div>
             
    </footer>

  <script src="app.js"></script>
</body>
</html>
